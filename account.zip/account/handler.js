const crypto = require('crypto');
// Repository is owner-scoped by a server-derived key. A duplicate insert must
// re-read the winner, never replace its randomly assigned product identity.
function createHandler({ context, repository, now = Date.now, randomId = () => crypto.randomBytes(24).toString('hex') }) {
  return async function bootstrap(event = {}) {
    if (event.action !== 'bootstrap' || event.protocolVersion !== 1) return { success:false, code:'UNSUPPORTED_PROTOCOL' };
    const { OPENID, APPID } = context();
    if (!OPENID || !APPID) return { success:false, code:'IDENTITY_UNAVAILABLE' };
    const key = crypto.createHash('sha256').update(JSON.stringify([APPID, OPENID])).digest('hex');
    try {
      let account = await repository.find(key);
      if (!account) {
        const candidate = { _id:key, userId:'u_' + randomId(), profileRevision:0, membershipVersion:0, createdAt:now() };
        try { await repository.insert(candidate); account = candidate; }
        catch (error) { account = await repository.find(key); if (!account) throw error; }
      }
      if (!/^u_[a-f0-9]{48}$/.test(account.userId)) return { success:false, code:'ACCOUNT_INVALID' };
      return { success:true, protocolVersion:1, userId:account.userId, profileRevision:account.profileRevision,
        membershipVersion:account.membershipVersion, serverTime:now(), capabilities:['private-cache-v1'] };
    } catch (error) { return { success:false, code:'ACCOUNT_UNAVAILABLE' }; }
  };
}
module.exports = { createHandler };
