# 本次修复

已将以下配置关闭，避免开发者工具在开发阶段过滤新增页面文件：

- project.config.json: ignoreDevUnusedFiles = false
- project.config.json: ignoreUploadUnusedFiles = false
- project.private.config.json: ignoreDevUnusedFiles = false
- project.private.config.json: ignoreUploadUnusedFiles = false
- compileHotReLoad = false
- 暂时移除 app.json 的 lazyCodeLoading，待页面稳定后再恢复。

请关闭微信开发者工具后重新打开此项目，再手动点击“编译”。
